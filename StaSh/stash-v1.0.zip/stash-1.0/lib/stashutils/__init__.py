# -*- coding: utf-8 -*-
"""utility functions and modules for StaSh-scripts"""