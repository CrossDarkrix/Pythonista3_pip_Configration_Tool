# -*- coding: utf-8 -*-
"""
Dummy File.
This directory contains the patches "monkeyloard" uses.
Later there will/may be a subdirectory called "modules", which contains modules added to sys.path.
"""
