# -*- coding: utf-8 -*-
import os

os.chdir('bin')