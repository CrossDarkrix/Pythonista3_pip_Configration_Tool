# -*- coding: utf-8 -*-
"""submodule test"""


def main():
    print("local pip test successfull!")
