# -*- coding: utf-8 -*-
"""local test package for StaSh pip."""
from stpkg.submod import main
